import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { useState } from 'react';
import './FileUpload.css';

const FileUpload = () => {
  // State to store uploaded data
  const [data, setData] = useState([]);
  // State to manage timing inputs for weekdays
  const [timing, setTiming] = useState({ Monday: '', Tuesday: '', Wednesday: '' });
  // State to track progress of PDF generation
  const [progress, setProgress] = useState(0);
  // State to determine if data is currently being filled and processed
  const [isFilling, setIsFilling] = useState(false);

  // Handle file input change event
  const handleFileChange = (event) => {
    const file = event.target.files[0]; // Get the uploaded file
    if (file) {
      const reader = new FileReader(); // Create a FileReader to read the file
      reader.onload = (e) => {
        const binaryStr = e.target.result; // Read file as binary string
        const workbook = XLSX.read(binaryStr, { type: 'binary' }); // Parse the binary string to a workbook
        const firstSheetName = workbook.SheetNames[0]; // Get the name of the first sheet
        const worksheet = workbook.Sheets[firstSheetName]; // Access the first sheet
        const jsonData = XLSX.utils.sheet_to_json(worksheet); // Convert the sheet to JSON format
        
        // Set the data for the preview in the state
        setData(jsonData);
      };
      reader.readAsBinaryString(file); // Read the file as binary string
    }
  };

  // Handle changes in timing input fields
  const handleTimingChange = (event) => {
    const { name, value } = event.target; // Destructure name and value from the event target
    // Update the corresponding timing value in state
    setTiming(prevTiming => ({ ...prevTiming, [name]: value }));
  };

  // Handle filling data and generating PDF
  const handleFillData = () => {
    const { Monday, Tuesday, Wednesday } = timing; // Destructure timing values
    // Check if at least one timing value is provided
    if (!Monday && !Tuesday && !Wednesday) {
      alert("Please enter timing values for at least one day.");
      return; // Exit if no values are provided
    }
    setIsFilling(true); // Indicate that data filling is in progress

    // Create a new data array with updated timing values
    const updatedData = data.map((row) => ({
      ...row,
      'Monday': Monday || row['Monday'], // Fill Monday if provided
      'Tuesday': Tuesday || row['Tuesday'], // Fill Tuesday if provided
      'Wednesday': Wednesday || row['Wednesday'], // Fill Wednesday if provided
    }));

    setData(updatedData); // Update the data state with new values
    setProgress(50); // Set progress to 50% as filling is in progress
    convertToPDF(updatedData); // Call function to convert data to PDF
  };

  // Convert updated data to PDF and download it
  const convertToPDF = (updatedData) => {
    // Check if there is data to convert
    if (updatedData.length === 0) {
      alert("No data to convert to PDF.");
      setIsFilling(false); // Reset filling state
      return; // Exit if no data is available
    }

    const doc = new jsPDF(); // Create a new jsPDF document
    const headers = updatedData.length > 0 ? Object.keys(updatedData[0]) : []; // Get headers from the first data row
    const bodyData = updatedData.map(row => Object.values(row)); // Convert rows to array of values

    // Generate a table in the PDF
    autoTable(doc, {
      head: [headers],
      body: bodyData,
    });

    doc.save('filled_data.pdf'); // Save the PDF with a specified name
    setProgress(100); // Set progress to 100% after generation
    setIsFilling(false); // Reset filling state

    // Reset timing input fields and data after PDF generation
    resetForm();
  };

  // Handle downloading the updated Excel file
  const handleDownloadExcel = () => {
    // Merge timing values into the original data for Excel download
    const updatedData = data.map((row) => ({
      ...row,
      ...timing // Spread timing object to include the values
    }));
    
    const worksheet = XLSX.utils.json_to_sheet(updatedData); // Convert updated data to a worksheet
    const workbook = XLSX.utils.book_new(); // Create a new workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, "Updated Data"); // Append the worksheet to the workbook
    XLSX.writeFile(workbook, 'updated_data.xlsx'); // Trigger download of the Excel file

    // Reset timing input fields and data after downloading Excel
    resetForm();
  };

  // Function to reset the form and state
  const resetForm = () => {
    setData([]); // Clear the uploaded data
    setTiming({ Monday: '', Tuesday: '', Wednesday: '' }); // Reset timing fields
    setProgress(0); // Reset progress
  };

  return (
    <div className="container">
      <div className="card">
        <h2 className="title">Upload Excel File</h2>
        
        <label htmlFor="file-upload" className="custom-file-upload">
          Choose Excel File
        </label>
        <input id="file-upload" type="file" accept=".xlsx, .xls" onChange={handleFileChange} />

        {data.length > 0 && ( // Render data preview if data exists
          <div className="data-section">
            <h3>Data Preview</h3>
            <table className="data-table">
              <thead>
                <tr>
                  {Object.keys(data[0]).map((header) => ( // Map through headers for table
                    <th key={header}>{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map((row, rowIndex) => (
                  <tr key={rowIndex}>
                    {Object.values(row).map((cell, cellIndex) => (
                      <td key={cellIndex}>{cell}</td> // Render each cell in the row
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="input-section">
                <h4>Add Time:</h4>
              {/* Timing input fields */}
              <label>Monday: </label>
              <input type="text" name="Monday" value={timing.Monday} onChange={handleTimingChange} />
              
              <label>Tuesday: </label>
              <input type="text" name="Tuesday" value={timing.Tuesday} onChange={handleTimingChange} />
              
              <label>Wednesday: </label>
              <input type="text" name="Wednesday" value={timing.Wednesday} onChange={handleTimingChange} />

              <button onClick={handleFillData} disabled={isFilling} className="fill-button">
                Fill Data & Convert to PDF
              </button>

              <button onClick={handleDownloadExcel} className="fill-button" disabled={isFilling}>
                Download Updated Excel
              </button>
            </div>

            {isFilling && <p>Filling data and converting to PDF, please wait...</p>} {/* Indicate processing state */}
            <progress value={progress} max="100" className="progress-bar">
              {progress}% {/* Display progress */}
            </progress>
          </div>
        )}
      </div>
    </div>
  );
};

export default FileUpload;
